﻿using Microsoft.AspNetCore.Mvc;
using Stripe.Checkout;

namespace BetalingsApp.Controllers
{
    [ApiController]
    [Route("checkout")] // 👈 URL-prefix
    public class CheckoutController : ControllerBase
    {
        public class PaymentData
        {
            public decimal Amount { get; set; }
        }

        [HttpPost("createsession")] // 👈 POST /checkout/createsession
        public IActionResult CreateSession([FromBody] PaymentData data)
        {
            Stripe.StripeConfiguration.ApiKey = "sk_test_51RWd3SPFsbG5c7qufpCYnSvXCcab1sATvCtfxpk8I9481Dw5k0DfJE8ORkUveo9yiQG6sbmAwqxK2kXOJeWLD5xl00bLZgpE9H";

            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string> { "card", "ideal" },
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            Currency = "eur",
                            UnitAmount = (long)(data.Amount * 100),
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = "Storting"
                            }
                        },
                        Quantity = 1
                    }
                },
                Mode = "payment",
                SuccessUrl = "https://localhost:5001/success",
                CancelUrl = "https://localhost:5001/pay"
            };

            var service = new SessionService();
            var session = service.Create(options);

            return new JsonResult(new { id = session.Id });
        }
    }
}
