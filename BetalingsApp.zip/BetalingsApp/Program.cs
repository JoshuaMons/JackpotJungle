var builder = WebApplication.CreateBuilder(args);

// Voeg Razor Pages en Controllers toe aan de DI-container
builder.Services.AddRazorPages();
builder.Services.AddControllers();

var app = builder.Build();

// Configureer de HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts(); // Production-only: HTTP Strict Transport Security
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization(); // Alleen nodig als je [Authorize] gebruikt

// Routes activeren
app.MapRazorPages();    // Voor Razor Pages zoals Pay.cshtml
app.MapControllers();   // Voor API-controllers zoals CheckoutController.cs

app.Run();
