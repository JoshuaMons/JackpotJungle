﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BetalingsApp.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

