using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BetalingsApp.Pages
{
    public class succesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
