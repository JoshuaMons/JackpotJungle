using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class FAQModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
