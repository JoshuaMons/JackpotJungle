using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep5Model : PageModel
    {
        public void OnGet()
        {
            
        }

        public void OnPost()
        {
            
        }
    }
}

