﻿namespace Jungle_Jackpot.Pages
{
    internal class MySqlConnection
    {
        private string? connStr;

        public MySqlConnection(string? connStr)
        {
            this.connStr = connStr;
        }
    }
}