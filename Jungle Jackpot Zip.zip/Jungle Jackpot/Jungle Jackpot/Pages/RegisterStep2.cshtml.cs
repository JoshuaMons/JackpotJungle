using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep2Model : PageModel
    {
        [BindProperty]
        public int DailyLimit { get; set; }

        [BindProperty]
        public int WeeklyLimit { get; set; }

        [BindProperty]
        public int MonthlyLimit { get; set; }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }


            HttpContext.Session.SetInt32("DailyLimit", DailyLimit);
            HttpContext.Session.SetInt32("WeeklyLimit", WeeklyLimit);
            HttpContext.Session.SetInt32("MonthlyLimit", MonthlyLimit);
            return RedirectToPage("/RegisterStep3");
            
        }
    }
}
