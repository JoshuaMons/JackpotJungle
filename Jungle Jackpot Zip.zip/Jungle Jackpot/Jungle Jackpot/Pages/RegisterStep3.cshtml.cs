using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep3Model : PageModel
    {
        [BindProperty]
        public string SelectedTimeLimit { get; set; } 

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(SelectedTimeLimit))
            {
                ModelState.AddModelError("SelectedTimeLimit", "Please select a time limit.");
                return Page();
            }


            return RedirectToPage("/RegisterStep4");
            HttpContext.Session.SetString("SelectedTimeLimit", SelectedTimeLimit);
        }
    }
}
