using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Jungle_Jackpot.Pages
{
    // Simpele User class hier gedefinieerd (kan je ook in aparte file zetten)
    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int DailyLimit { get; set; }
        public int WeeklyLimit { get; set; }
        public int MonthlyLimit { get; set; }
        public string SelectedTimeLimit { get; set; }
        public bool SetBalanceLimit { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // Pas hier eventueel de naam aan als jouw context anders heet
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    }

    public class RegisterStep5Model : PageModel
    {
        private readonly ApplicationDbContext _context;

        public RegisterStep5Model(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty] public string Email { get; set; }
        [BindProperty] public string Password { get; set; }
        [BindProperty] public int? DailyLimit { get; set; }
        [BindProperty] public int? WeeklyLimit { get; set; }
        [BindProperty] public int? MonthlyLimit { get; set; }
        [BindProperty] public string SelectedTimeLimit { get; set; }
        [BindProperty] public bool SetBalanceLimit { get; set; }

        public void OnGet()
        {
            Email = HttpContext.Session.GetString("Email");
            Password = HttpContext.Session.GetString("Password");
            DailyLimit = HttpContext.Session.GetInt32("DailyLimit");
            WeeklyLimit = HttpContext.Session.GetInt32("WeeklyLimit");
            MonthlyLimit = HttpContext.Session.GetInt32("MonthlyLimit");
            SelectedTimeLimit = HttpContext.Session.GetString("SelectedTimeLimit");

            var balanceLimit = HttpContext.Session.GetString("SetBalanceLimit");
            SetBalanceLimit = bool.TryParse(balanceLimit, out bool parsed) && parsed;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = new User
            {
                Email = Email,
                Password = Password,
                DailyLimit = DailyLimit ?? 0,
                WeeklyLimit = WeeklyLimit ?? 0,
                MonthlyLimit = MonthlyLimit ?? 0,
                SelectedTimeLimit = SelectedTimeLimit,
                SetBalanceLimit = SetBalanceLimit
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            HttpContext.Session.Clear();

            return RedirectToPage("/Login");
        }
    }
}
