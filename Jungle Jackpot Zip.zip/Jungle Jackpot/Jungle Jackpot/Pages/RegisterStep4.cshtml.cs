using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep4Model : PageModel
    {
        [BindProperty]
        public bool SetBalanceLimit { get; set; }

        public IActionResult OnPost()
        {

            HttpContext.Session.SetString("SetBalanceLimit", SetBalanceLimit.ToString());

            return RedirectToPage("/RegisterStep5");
        }
    }
}
