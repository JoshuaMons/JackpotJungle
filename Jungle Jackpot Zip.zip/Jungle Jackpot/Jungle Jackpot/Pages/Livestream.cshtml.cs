
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPages.Pages
{
    public class LivestreamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
