using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages.Shared
{
    public class LayoutLoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
