using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public IActionResult OnPost()
        {
            if (Username == "admin" && Password == "123")
            {
                HttpContext.Session.SetString("Username", Username);
                HttpContext.Session.SetString("Balance", "�1.250,00");
                return RedirectToPage("Index");

            }

            ModelState.AddModelError(string.Empty, "Ongeldige inloggegevens");
            return Page();
        }
    }
}
