﻿using System.Security.Cryptography;
using System.Text;

namespace Jungle_Jackpot.Classes
{
    public class User
    {

        public string Email { get; set; }
        public string Password { get; set; }

        public string ComputeSha256Hash()
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(this.Password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
