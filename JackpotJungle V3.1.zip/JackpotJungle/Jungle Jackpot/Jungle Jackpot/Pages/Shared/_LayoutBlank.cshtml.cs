using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages.Shared
{
    public class _LayoutBlankModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
