﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace Jungle_Jackpot.Pages
{
    public class SportModel : PageModel
    {
        public class Match
        {
            public int Id { get; set; }
            public string HomeTeam { get; set; } = "";
            public string AwayTeam { get; set; } = "";
            public int? HomeGoals { get; set; }
            public int? AwayGoals { get; set; }
            public DateTime Time { get; set; }
            public string Round { get; set; } = "";
        }

        public List<Match> Matches { get; set; } = new();

        public async Task<IActionResult> OnGetMatchesJsonAsync(int leagueId, string? team, string? date)
        {
            var allMatches = new List<Match>();
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("x-apisports-key", "eaa81e7a726ee23103508c208dc1c3f9");

            int season = 2023; 
            string url = $"https://v3.football.api-sports.io/fixtures?league={leagueId}&season={season}&status=FT";

            var response = await client.GetAsync(url);
            if (!response.IsSuccessStatusCode) return new JsonResult(allMatches);

            using var stream = await response.Content.ReadAsStreamAsync();
            var json = await JsonDocument.ParseAsync(stream);
            var fixtures = json.RootElement.GetProperty("response");

            foreach (var fixture in fixtures.EnumerateArray())
            {
                var home = fixture.GetProperty("teams").GetProperty("home").GetProperty("name").GetString();
                var away = fixture.GetProperty("teams").GetProperty("away").GetProperty("name").GetString();
                var matchDate = fixture.GetProperty("fixture").GetProperty("date").GetDateTime();
                var rawRound = fixture.GetProperty("league").GetProperty("round").GetString() ?? "Onbekend";
                var round = rawRound.Replace("Regular Season -", "Speelronde").Trim();
                var competition = leagueId == 88 ? "Eredivisie" : "Keuken Kampioen Divisie";

                if (!string.IsNullOrEmpty(team) && !(home?.ToLower().Contains(team.ToLower()) == true || away?.ToLower().Contains(team.ToLower()) == true))
                    continue;

                if (!string.IsNullOrEmpty(date) && !matchDate.ToString("yyyy-MM-dd").Equals(date))
                    continue;

                allMatches.Add(new Match
                {
                    Id = fixture.GetProperty("fixture").GetProperty("id").GetInt32(),
                    HomeTeam = home ?? "?",
                    AwayTeam = away ?? "?",
                    HomeGoals = fixture.GetProperty("goals").GetProperty("home").GetInt32(),
                    AwayGoals = fixture.GetProperty("goals").GetProperty("away").GetInt32(),
                    Time = matchDate,
                    Round = $"{competition} - {round}"
                });
            }

            var grouped = allMatches
                .GroupBy(m => m.Round)
                .Select(g => new {
                    round = g.Key,
                    matches = g.OrderBy(m => m.Time).ToList()
                })
                .OrderBy(g => g.round);

            return new JsonResult(grouped);

        }
    }
}
