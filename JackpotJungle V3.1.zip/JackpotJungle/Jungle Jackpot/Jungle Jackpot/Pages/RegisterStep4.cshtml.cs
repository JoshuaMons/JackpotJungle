using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep4Model : PageModel
    {
        [BindProperty]
        public bool SetBalanceLimit { get; set; }

        public IActionResult OnPost()
        {

            return RedirectToPage("/RegisterStep5");
        }
    }
}
