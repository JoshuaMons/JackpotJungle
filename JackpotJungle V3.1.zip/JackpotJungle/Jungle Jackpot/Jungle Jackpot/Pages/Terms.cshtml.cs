using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class TermsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
