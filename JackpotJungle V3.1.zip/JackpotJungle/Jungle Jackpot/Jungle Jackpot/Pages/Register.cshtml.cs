using Jungle_Jackpot.Classes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Jungle_Jackpot.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly IConfiguration _config;

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public RegisterModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid || string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError(string.Empty, "Vul alle velden correct in.");
                return Page();
            }

            try
            {
                User newUser = new User();
                newUser.Email = Email;
                newUser.Password = Password;



                string passwordHash = newUser.ComputeSha256Hash();

                var connStr = _config.GetConnectionString("MySqlConnection");
                using var conn = new MySqlConnection(connStr);
                conn.Open();

                var cmd = new MySqlCommand("INSERT INTO users (username, password_hash, email, balance) VALUES (@username, @password_hash, @email, 0)", conn);
                cmd.Parameters.AddWithValue("@username", newUser.Email);
                cmd.Parameters.AddWithValue("@password_hash", passwordHash);
                cmd.Parameters.AddWithValue("@email", newUser.Email);

                cmd.ExecuteNonQuery();

                HttpContext.Session.SetString("Username", newUser.Email);
                HttpContext.Session.SetString("Balance", "�0,00");

                return RedirectToPage("/Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Registratiefout: {ex.Message}");
                return Page();
            }
        }

        
    }
}
