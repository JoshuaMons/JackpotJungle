﻿namespace Jungle_Jackpot.Pages
{
    public class PlayResponsably
    {
    }
}
