using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Jungle_Jackpot.Pages
{
    public class RegisterModel : PageModel
    {
        private readonly IConfiguration _config;

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public RegisterModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid || string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError(string.Empty, "Vul alle velden correct in.");
                return Page();
            }

            try
            {
                string passwordHash = ComputeSha256Hash(Password);
                var connStr = _config.GetConnectionString("MySqlConnection");
                using var conn = new MySqlConnection(connStr);
                conn.Open();

                var cmd = new MySqlCommand("INSERT INTO users (username, password_hash, email, balance) VALUES (@username, @password_hash, @email, 0)", conn);
                cmd.Parameters.AddWithValue("@username", Email);
                cmd.Parameters.AddWithValue("@password_hash", passwordHash);
                cmd.Parameters.AddWithValue("@email", Email);

                cmd.ExecuteNonQuery();

                HttpContext.Session.SetString("Username", Email);
                HttpContext.Session.SetString("Balance", "�0,00");

                return RedirectToPage("/Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Registratiefout: {ex.Message}");
                return Page();
            }
        }

        private string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
