using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RanglijstenModel : PageModel
    {
        public class Speler
        {
            public int Positie { get; set; }
            public string Gebruikersnaam { get; set; } = "";
            public int Score { get; set; }
            public string Spel { get; set; } = "";
        }

        public List<Speler> Spelers { get; set; } = new();

        public void OnGet()
        {
       
            Spelers = new List<Speler>
            {
                new Speler { Positie = 1, Gebruikersnaam = "LuckyLeo", Score = 15230, Spel = "Mega Fortune" },
                new Speler { Positie = 2, Gebruikersnaam = "SlotQueen", Score = 14000, Spel = "Sweet Bonanza" },
                new Speler { Positie = 3, Gebruikersnaam = "RouletteRik", Score = 12850, Spel = "Roulette Royale" },
                new Speler { Positie = 4, Gebruikersnaam = "CrazyCat", Score = 11700, Spel = "Crazy Time" },
                new Speler { Positie = 5, Gebruikersnaam = "JackpotJeroen", Score = 10950, Spel = "Book of Dead" },
            };
        }
    }
}
