﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class PromotiesModel : PageModel
    {
        public class Promo
        {
            public string Titel { get; set; } = "";
            public string Beschrijving { get; set; } = "";
            public string AfbeeldingUrl { get; set; } = "";
            public string GeldigTot { get; set; } = "";
        }

        public List<Promo> ActievePromoties { get; set; } = new();

        public void OnGet()
        {
            ActievePromoties = new List<Promo>
            {
                new Promo
                {
                    Titel = "🎁 Welkomstbonus 100%",
                    Beschrijving = "Verdubbel je eerste storting tot €200 en ontvang 50 gratis spins!",
                    AfbeeldingUrl = "https://cdn-icons-png.flaticon.com/512/2304/2304331.png",
                    GeldigTot = "31 juli 2025"
                },
                new Promo
                {
                    Titel = "🔄 Cashback Maandag",
                    Beschrijving = "Krijg tot 10% cashback op verloren inzetten elke maandag.",
                    AfbeeldingUrl = "https://cdn-icons-png.flaticon.com/512/616/616408.png",
                    GeldigTot = "Elke maandag"
                },
                new Promo
                {
                    Titel = "💎 VIP Programma",
                    Beschrijving = "Word VIP en ontvang exclusieve bonussen, snellere uitbetalingen en persoonlijke service.",
                    AfbeeldingUrl = "https://cdn-icons-png.flaticon.com/512/1828/1828884.png",
                    GeldigTot = "Permanent"
                }
            };
        }
    }
}
