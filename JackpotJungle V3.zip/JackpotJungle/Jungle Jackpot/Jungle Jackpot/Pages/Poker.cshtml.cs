using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class PokerModel : PageModel
    {
        public class PokerGame
        {
            public string Naam { get; set; } = "";
            public string Type { get; set; } = "";
            public string Spelers { get; set; } = "";
            public string Beschrijving { get; set; } = "";
        }

        public List<PokerGame> PokerSpellen { get; set; } = new();

        public void OnGet()
        {
            PokerSpellen = new List<PokerGame>
            {
                new PokerGame
                {
                    Naam = "Texas Hold'em",
                    Type = "Toernooi",
                    Spelers = "2-9 spelers",
                    Beschrijving = "De populairste vorm van poker met community kaarten."
                },
                new PokerGame
                {
                    Naam = "Omaha",
                    Type = "Cashgame",
                    Spelers = "2-6 spelers",
                    Beschrijving = "Lijkt op Hold'em, maar je krijgt 4 kaarten."
                },
                new PokerGame
                {
                    Naam = "Three Card Poker",
                    Type = "Live tafel",
                    Spelers = "1-5 spelers",
                    Beschrijving = "Versla de dealer met jouw beste 3 kaarten."
                },
                new PokerGame
                {
                    Naam = "Caribbean Stud",
                    Type = "Live tafel",
                    Spelers = "1 speler vs dealer",
                    Beschrijving = "Klassiek pokerspel met progressieve jackpot."
                }
            };
        }
    }
}
