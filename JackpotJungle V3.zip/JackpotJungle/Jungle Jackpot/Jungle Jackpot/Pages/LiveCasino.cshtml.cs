using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class LiveCasinoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
