using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Security.Cryptography;
using System.Text;

namespace Jungle_Jackpot.Pages
{
    public class LoginModel : PageModel
    {
        private readonly IConfiguration _config;

        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public LoginModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid || string.IsNullOrEmpty(Username) || string.IsNullOrEmpty(Password))
            {
                ModelState.AddModelError(string.Empty, "Vul alle velden in.");
                return Page();
            }

            try
            {
                string passwordHash = ComputeSha256Hash(Password);
                var connStr = _config.GetConnectionString("MySqlConnection");
                using var conn = new MySqlConnection(connStr);
                conn.Open();

                var cmd = new MySqlCommand("SELECT balance FROM users WHERE username = @username AND password_hash = @password_hash", conn);
                cmd.Parameters.AddWithValue("@username", Username);
                cmd.Parameters.AddWithValue("@password_hash", passwordHash);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    decimal balance = reader.GetDecimal("balance");
                    HttpContext.Session.SetString("Username", Username);
                    HttpContext.Session.SetString("Balance", balance.ToString("C2"));
                    return RedirectToPage("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Ongeldige gebruikersnaam of wachtwoord.");
                    return Page();
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Fout bij inloggen: {ex.Message}");
                return Page();
            }
        }

        private string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
