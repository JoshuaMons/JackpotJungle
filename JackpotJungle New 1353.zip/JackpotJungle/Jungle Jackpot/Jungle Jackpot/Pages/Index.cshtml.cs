﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;

namespace Jungle_Jackpot.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _config;

        public bool ShowAlert { get; set; }
        public string AlertMessage { get; set; }

        public IndexModel(IConfiguration config)
        {
            _config = config;
        }

        public void OnGet()
        {
            try
            {
                var connStr = _config.GetConnectionString("MySqlConnection");
                using var conn = new MySqlConnection(connStr);
                conn.Open();

                ShowAlert = true;
                AlertMessage = "✅ Verbinding met database geslaagd!";
            }
            catch (Exception ex)
            {
                ShowAlert = true;
                AlertMessage = $"❌ Verbindingsfout: {ex.Message}";
            }
        }
    }
}
