using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Jungle_Jackpot.Pages
{
    public class RegisterStep2Model : PageModel
    {
        [BindProperty]
        public int DailyLimit { get; set; }

        [BindProperty]
        public int WeeklyLimit { get; set; }

        [BindProperty]
        public int MonthlyLimit { get; set; }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

         

            return RedirectToPage("/RegisterStep3");
        }
    }
}
